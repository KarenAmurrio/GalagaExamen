// Fill out your copyright notice in the Description page of Project Settings.


#include "IBounce_Ball.h"

// Add default functionality here for any IIBounce_Ball functions that are not pure virtual.
