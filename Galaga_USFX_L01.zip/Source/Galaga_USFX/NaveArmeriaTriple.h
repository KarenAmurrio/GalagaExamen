// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "NaveArmeria.h"
#include "NaveArmeriaTriple.generated.h"

/**
 * 
 */
UCLASS()
class GALAGA_USFX_API ANaveArmeriaTriple : public ANaveArmeria
{
	GENERATED_BODY()
	
};
